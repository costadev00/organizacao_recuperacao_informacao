#read the input folder
